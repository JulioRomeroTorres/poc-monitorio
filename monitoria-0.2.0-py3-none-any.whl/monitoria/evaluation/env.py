"""
Environment utilities for Azure OpenAI configuration and credentials.
"""
from __future__ import annotations

import os
from typing import Optional
import pandas as pd
from azure.ai.evaluation import AzureOpenAIModelConfiguration
from azure.identity import DefaultAzureCredential, AzureCliCredential

def set_azure_openai_env(
    *,
    endpoint: str,
    deployment: str,
    api_version: str,
    api_key: Optional[str] = None,
) -> None:
    """
    Sets the required environment variables for Azure OpenAI SDK.

    Args:
        endpoint: The Azure OpenAI endpoint URL.
        deployment: The Azure OpenAI deployment name.
        api_version: The API version to use.
        api_key: The authentication key (optional if using entra identity).
    """
    os.environ["AZURE_OPENAI_API_VERSION"] = api_version
    os.environ["AZURE_OPENAI_DEPLOYMENT"] = deployment
    os.environ["AZURE_OPENAI_ENDPOINT"] = endpoint
    if api_key:
        os.environ["AZURE_OPENAI_KEY"] = api_key

def load_jsonl_dataframe(path: str) -> pd.DataFrame:
    """
    Loads a JSON Lines (JSONL) file into a pandas DataFrame.

    Args:
        path: The file path to the JSONL data.

    Returns:
        pd.DataFrame: A pandas DataFrame containing the parsed data.
    """
    return pd.read_json(path, lines=True)

def build_model_config_from_env() -> AzureOpenAIModelConfiguration:
    """
    Builds an AzureOpenAIModelConfiguration instance using the standard 
    Azure OpenAI environment variables.

    Returns:
        AzureOpenAIModelConfiguration: The instantiated model configuration.
    """
    return AzureOpenAIModelConfiguration(
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=os.environ.get("AZURE_OPENAI_DEPLOYMENT"),
        api_key=os.environ.get("AZURE_OPENAI_KEY"),
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION"),
    )

def get_default_credential(use_cli_fallback: bool = False):
    """
    Retrieves the Default Azure Credential for authentication.
    
    Args:
        use_cli_fallback: If True, falls back to AzureCliCredential if the default fails.

    Returns:
        TokenCredential: An authenticated credential object from azure-identity.
    """
    try:
        return DefaultAzureCredential()
    except Exception:
        if use_cli_fallback:
            return AzureCliCredential()
        raise

__all__ = [
    "set_azure_openai_env",
    "load_jsonl_dataframe",
    "build_model_config_from_env",
    "get_default_credential",
]
