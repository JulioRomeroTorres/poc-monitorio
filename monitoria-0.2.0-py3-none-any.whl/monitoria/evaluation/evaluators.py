"""
Evaluators module wrapping multiple Language Model (LLM) judgment instances.
Provides dynamic integration of multiple built-in Azure NLP / AI metrics alongside custom Prompty-based judge logic.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Union
from promptflow.core import Prompty

from azure.ai.evaluation import (
    AzureOpenAIModelConfiguration,
    GroundednessEvaluator,
    FluencyEvaluator,
    CoherenceEvaluator,
    RelevanceEvaluator,
    ContentSafetyEvaluator,
    BleuScoreEvaluator,
    RougeScoreEvaluator,
    RougeType,
    F1ScoreEvaluator,
    MeteorScoreEvaluator,
    SimilarityEvaluator,
)

def _as_aoai_config(model_config: Any, *, override_deployment: Optional[str] = None) -> AzureOpenAIModelConfiguration:
    """
    Normalizes parsing the configuration into a strict `AzureOpenAIModelConfiguration` object irrespective of 
    whether the input object is a standard dict, TypedDict, or nested object structure.
    """
    # Verify dictionary/TypedDict structure approach
    if isinstance(model_config, dict):
        deployment = override_deployment or model_config.get("azure_deployment")
        return AzureOpenAIModelConfiguration(
            azure_endpoint=model_config.get("azure_endpoint"),
            azure_deployment=deployment,
            api_key=model_config.get("api_key"),
            api_version=model_config.get("api_version"),
        )
        
    # Standard Python object configuration
    deployment = override_deployment or getattr(model_config, "azure_deployment", None)
    return AzureOpenAIModelConfiguration(
        azure_endpoint=getattr(model_config, "azure_endpoint", None),
        azure_deployment=deployment,
        api_key=getattr(model_config, "api_key", None),
        api_version=getattr(model_config, "api_version", None),
    )

def _list_prompty_files(prompty_dir: str, pattern: str) -> List[Path]:
    """
    Scans the provided directory yielding files matching the valid glob pattern.
    """
    p = Path(prompty_dir)
    if not p.exists() or not p.is_dir():
        raise ValueError(f"custom_judge_prompty_dir does not exist or is not a directory: {prompty_dir}")
    files = sorted(p.glob(pattern))
    if not files:
        raise ValueError(f"No prompty files found in '{prompty_dir}' with pattern '{pattern}'")
    return files

import re

def _prompty_display_name(prompty_path: Path) -> str:
    """
    Attempts to read the internal markdown header metadata block (frontmatter) of the specific Prompty file 
    to extract the evaluation name dynamically, dropping back to the pure OS filename base on failures.
    """
    text = prompty_path.read_text(encoding="utf-8", errors="ignore")
    parts = text.split("---", 2)
    if len(parts) < 3:
        return prompty_path.stem

    front_matter = parts[1]
    m = re.search(r"(?m)^\s*name\s*:\s*(.+?)\s*$", front_matter)
    if not m:
        return prompty_path.stem

    name = m.group(1).strip().strip('"').strip("'")
    return name or prompty_path.stem

def _judge_key_from_prompty(prompty_path: Path, *, prefix: str = "llmaaj_") -> str:
    """Converts a Prompty title to snake_case structure appending the designated prefix."""
    title = _prompty_display_name(prompty_path)
    return f"{prefix}{_to_snake(title)}"


def _to_snake(s: str) -> str:
    """Converts arbitrary strings into lowercase normalized snake_case structures."""
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s)
    return s.strip("_")

def _judge_key(fp: Path) -> str:
    """Standardizes prefixing file paths onto valid OS-independent reference keys."""
    return "llmaaj_" + _to_snake(fp.stem)

def list_custom_judge_keys(prompty_dir: str, pattern: str) -> List[str]:
    """
    List names assigned internally mapped to dynamic custom judge metric keys automatically.
    """
    files = _list_prompty_files(prompty_dir, pattern)
    keys = []
    for fp in files:
        k = _judge_key(fp)
        if k in keys:
            k = f"{k}_{_to_snake(fp.name)}"
        keys.append(k)
    return keys

# ----------------------------------------------------
# Custom Language-Model-as-a-Judge Formatter (Prompty)
# ----------------------------------------------------

class CustomPromptyJudgeEvaluator:
    """
    Registers a custom internal Language Model runtime to serve strictly as an autonomous evaluator (LLM-as-a-judge).
    Loads grading mechanisms via `.prompty` templates pointing metrics evaluations to dynamic contexts.
    """
    def __init__(
        self,
        *,
        model_config: Union[AzureOpenAIModelConfiguration, Dict[str, str]],
        prompty_path: str,
    ):
        model_override = {
            "configuration" : {
                "type" : "azure_openai",
                "azure_endpoint" : model_config.get("azure_endpoint"),
                "azure_deployment" : model_config.get("azure_deployment"),
                "api_key" : model_config.get("api_key"), 
                "api_version" : model_config.get("api_version"),
            }
        }
        self._prompty = Prompty.load(
            source=prompty_path,
            model=model_override,
        )

    def __call__(
        self,
        *,
        query: str,
        response: str,
        ground_truth: str = "N/A",
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Executes an inference with the judge model loading the context variables.
        Expected JSON output holds the numeric score and evaluation reason.
        """
        llm_response = self._prompty(
            query=query,
            response=response,
            ground_truth=ground_truth or "N/A",
        )

        try:
            parsed = json.loads(llm_response) if isinstance(llm_response, str) else llm_response
        except Exception:
            parsed = {
                "score": 0.0,
                "reason": f"Failed to parse target JSON from the LLM judge output: {str(llm_response)[:200]}",
            }

        score = float(parsed.get("score", 0.0))
        reason = (
            parsed.get("reason")
            or parsed.get("explanation")
            or parsed.get("explain")
            or ""
        )
        
        return {"score": score, "reason": str(reason)}

# ----------------------------
# Internal Evaluators Instance Initializer
# ----------------------------

def build_evaluators(
    *,
    model_config: Union[AzureOpenAIModelConfiguration, Dict[str, str]],
    credential: Any,
    azure_ai_project: str,
    similarity_threshold: int = 3,
    content_safety_thresholds: Optional[Dict[str, int]] = None,
    enabled: Optional[Iterable[str]] = None,

    # Configuration for custom LLM-as-a-judge engines
    enable_custom_judges: bool = False,
    custom_judge_model: Optional[str] = None,               
    custom_judge_prompty_dir: Optional[str] = None,         
    custom_judge_pattern: str = "*.prompty",               
    custom_judge_name_prefix: str = "",                     
) -> Dict[str, Any]:
    """
    Initializes built-in Azure NLP models and configures runtime execution logic spanning baseline relevance
    to comprehensive content safety logic. Integrates optionally with dynamic custom prompt-based models if flagged.
    """
    if content_safety_thresholds is None:
        content_safety_thresholds = {
            "violence_threshold": 3,
            "sexual_threshold": 3,
            "self_harm_threshold": 3,
            "hate_unfairness_threshold": 3,
        }

    # Format explicitly isolated judge model configurations alongside default evaluators
    base_cfg = _as_aoai_config(model_config)
    judge_cfg = _as_aoai_config(model_config, override_deployment=custom_judge_model)

    # Built-in Traditional NLP metric objects
    bleu_evaluator = BleuScoreEvaluator()
    rougeL_evaluator = RougeScoreEvaluator(rouge_type=RougeType.ROUGE_L)
    meteor_evaluator = MeteorScoreEvaluator()
    f1_evaluator = F1ScoreEvaluator()

    # Pre-compiled LLM-as-a-judge mechanisms integrated from Azure 
    similarity_evaluator = SimilarityEvaluator(base_cfg, threshold=similarity_threshold)
    groundedness_evaluator = GroundednessEvaluator(base_cfg)
    fluency_evaluator = FluencyEvaluator(base_cfg)
    coherence_evaluator = CoherenceEvaluator(base_cfg)
    relevance_evaluator = RelevanceEvaluator(base_cfg)

    # Centralized robust Content safety evaluation node
    content_safety_evaluator = ContentSafetyEvaluator(
        credential=credential,
        azure_ai_project=azure_ai_project,
        **content_safety_thresholds,
    )

    all_evaluators: Dict[str, Any] = {
        "relevance": relevance_evaluator,
        "groundedness": groundedness_evaluator,
        "fluency": fluency_evaluator,
        "coherence": coherence_evaluator,
        "content_safety": content_safety_evaluator,
        "bleu": bleu_evaluator,
        "rougeL": rougeL_evaluator,
        "meteor": meteor_evaluator,
        "f1": f1_evaluator,
        "similarity": similarity_evaluator,
    }

    # Automatically map valid local folder paths to Custom LLM-as-a-judge nodes
    if enable_custom_judges:
        if not custom_judge_prompty_dir:
            raise ValueError("enable_custom_judges=True requires custom_judge_prompty_dir")

        prompty_files = _list_prompty_files(custom_judge_prompty_dir, custom_judge_pattern)

        for fp in prompty_files:
            name = _judge_key(fp)
            if name in all_evaluators:
                name = f"{name}_{_to_snake(fp.name)}"

            all_evaluators[name] = CustomPromptyJudgeEvaluator(
                model_config=judge_cfg,
                prompty_path=str(fp),
            )

    if enabled is None:
        return all_evaluators

    enabled_list: List[str] = list(enabled)
    unknown = [name for name in enabled_list if name not in all_evaluators]
    if unknown:
        raise ValueError(
            f"Unknown evaluator names requested: {unknown}. "
            f"Valid names are: {list(all_evaluators.keys())}"
        )

    return {name: all_evaluators[name] for name in enabled_list}


def build_evaluator_config(
    *,
    enabled: Optional[Iterable[str]] = None,
    include_custom_judges: bool = False,
    custom_judge_prompty_dir: Optional[str] = None,
    custom_judge_pattern: str = "*.prompty",
    custom_judge_name_prefix: str = "",
    custom_judge_names: Optional[Sequence[str]] = None,
) -> Dict[str, Dict[str, Dict[str, str]]]:
    """
    Mapping directory interface responsible for structuring variable keys into valid contexts matching the 
    data payload mapped automatically against respective components.
    """
    all_config: Dict[str, Dict[str, Dict[str, str]]] = {
        "relevance": {
            "column_mapping": {
                "response": "${target.response}",
                "context": "${data.context}",
                "query": "${data.query}",
            },
        },
        "groundedness": {
            "column_mapping": {
                "response": "${target.response}",
                "context": "${data.context}",
                "query": "${data.query}",
            },
        },
        "fluency": {
            "column_mapping": {
                "response": "${target.response}",
            },
        },
        "coherence": {
            "column_mapping": {
                "query": "${data.query}",
                "response": "${target.response}",
            },
        },
        "content_safety": {
            "column_mapping": {
                "query": "${data.query}",
                "response": "${target.response}",
            },
        },
        "bleu": {
            "column_mapping": {
                "response": "${target.response}",
                "ground_truth": "${data.ground_truth}",
            },
        },
        "rougeL": {
            "column_mapping": {
                "response": "${target.response}",
                "ground_truth": "${data.ground_truth}",
            },
        },
        "meteor": {
            "column_mapping": {
                "response": "${target.response}",
                "ground_truth": "${data.ground_truth}",
            },
        },
        "f1": {
            "column_mapping": {
                "response": "${target.response}",
                "ground_truth": "${data.ground_truth}",
            },
        },
        "similarity": {
            "column_mapping": {
                "query": "${data.query}",
                "response": "${target.response}",
                "ground_truth": "${data.ground_truth}",
            },
        }
    }

    if include_custom_judges:
        if custom_judge_names is not None:
            judge_names = list(custom_judge_names)
        else:
            if not custom_judge_prompty_dir:
                raise ValueError("include_custom_judges=True requires custom_judge_prompty_dir (or custom_judge_names)")
            prompty_files = _list_prompty_files(custom_judge_prompty_dir, custom_judge_pattern)


            judge_names = []

            for fp in prompty_files:
                name = _judge_key(fp)
                if name in judge_names:
                    name = f"{name}_{_to_snake(fp.name)}"
                judge_names.append(name)



        for name in judge_names:
            all_config[name] = {
                "column_mapping": {
                    "query": "${data.query}",
                    "response": "${target.response}",
                    "ground_truth": "${data.ground_truth}",
                },
            }

    if enabled is None:
        return all_config

    enabled_list: List[str] = list(enabled)
    unknown = [name for name in enabled_list if name not in all_config]
    if unknown:
        raise ValueError(
            f"Unknown evaluator names requested in config: {unknown}. "
            f"Valid names are: {list(all_config.keys())}"
        )

    return {name: all_config[name] for name in enabled_list}


__all__ = [
    "build_evaluators",
    "build_evaluator_config",
    "CustomPromptyJudgeEvaluator",
]
