"""
Endpoints module containing HTTP client logic for connecting to different LLM providers.
Supports fetching inferences and structuring standard responses.
"""
from __future__ import annotations

import time
import requests
from typing import Any, Dict, Optional
from typing import TypedDict
from typing_extensions import Self

try:
    from promptflow.tracing import trace
except Exception:
    def trace(f): return f

from copy import deepcopy
_REQUEST_KEYS = {"_headers", "_timeout", "_method"}

def _deep_merge(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    """
    Recursively deep merge two dictionaries.

    Args:
        a: The base dictionary.
        b: The dictionary properties to merge into the base.

    Returns:
        Dict[str, Any]: The recursively merged dictionary result.
    """
    out = deepcopy(a)
    for k, v in (b or {}).items():
        if (
            k in out
            and isinstance(out[k], dict)
            and isinstance(v, dict)
        ):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _split_request_kwargs(kwargs: Dict[str, Any]) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Splits keyword arguments into payload overrides and HTTP request overrides based on reserved keys.
    """
    request_overrides = {k: v for k, v in kwargs.items() if k in _REQUEST_KEYS and v is not None}
    payload_overrides = {k: v for k, v in kwargs.items() if k not in _REQUEST_KEYS and v is not None}
    return payload_overrides, request_overrides


def _render_template(obj: Any, query: str) -> Any:
    """
    Renders the evaluation query string dynamically into the given payload payload structure recursively.
    """
    if isinstance(obj, str):
        return obj.replace("${query}", query)
    if isinstance(obj, dict):
        return {k: _render_template(v, query) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_render_template(v, query) for v in obj]
    return obj

def _extract_from_path(data: Any, path: Optional[str]) -> Any:
    """
    Extracts a scalar value from a deeply nested dictionary or list according to a dot-separated path string.
    Treats numeric segments as list indices.
    """
    if not path:
        return data

    current: Any = data
    for part in path.split("."):
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list):
            # Treat numeric segments as indices
            if part.isdigit():
                idx = int(part)
                if idx < 0 or idx >= len(current):
                    return None
                current = current[idx]
            else:
                # Target path node is not a digit but the current object is a list; cannot index it
                return None
        else:
            return None

        if current is None:
            return None

    return current

class Response(TypedDict, total=False):
    """
    Standard response dictionary format parsed from endpoints.
    """
    query: str
    response: str
    latency_ms: float


class ModelEndpoints:
    """
    Factory interface to securely forward dynamic evaluation HTTP payload requests to multiple LLM backend vendors.
    Supported vendors: Azure OpenAI ("openai"), Anthropic ("anthropic"), Grok ("grok"), or user-defined ("custom").
    """
    def __init__(self: Self, env: Dict[str, Dict[str, str]], model_type: str) -> None:
        self.env = env
        self.model_type = model_type

    def _post(
        self,
        endpoint: str,
        headers: Dict[str, str],
        payload: Dict[str, Any],
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """
        Executes a normalized HTTP POST request against the remote vendor.
        """
        r = requests.post(
            url=endpoint,
            headers=headers,
            json=payload,
            timeout=timeout,
        )
        r.raise_for_status()
        return r.json()

    @trace
    def __call__(self: Self, query: str, **kwargs) -> Response:
        """
        Invokes the model endpoint for generative behavior by mapping standard evaluation requests to vendor-dependent forms.
        """
        cfg = self.env.get(self.model_type)
        if not cfg:
            raise ValueError(f"Model type '{self.model_type}' not found in env configuration.")
    
        vendor = cfg.get("vendor")

        payload_overrides, request_overrides = _split_request_kwargs(kwargs)
    
        start = time.perf_counter()
        
        if vendor == "openai":
            return self._call_aoai(self.model_type, query, payload_overrides, request_overrides)
        elif vendor == "anthropic":
            return self._call_anthropic(self.model_type, query, payload_overrides, request_overrides)
        elif vendor == "grok":
            return self._call_grok(self.model_type, query, payload_overrides, request_overrides)
        elif vendor == "custom":
            return self._call_custom(self.model_type, query, payload_overrides, request_overrides)
        else:
            raise ValueError(f"Unsupported vendor '{vendor}' for model '{self.model_type}'.")

    def _call_aoai(
        self, env_key: str, query: str,
        payload_overrides: Dict[str, Any],
        request_overrides: Dict[str, Any],
    ) -> Response:
        """Process Azure OpenAI SDK API requests."""
        start = time.perf_counter()
        cfg = self.env[env_key]
    
        headers = {
            "Content-Type": "application/json",
            "api-key": cfg["key"],
        }
        headers = {**headers, **(request_overrides.get("_headers") or {})}
    
        payload = {
            "messages": [{"role": "user", "content": query}],
            "max_tokens": 500,
            "model": self.model_type,
        }
        
        # Merge dictionary objects applying precedence rules
        payload = _deep_merge(payload, cfg.get("default_params", {}) or {})
        # Apply strict per-call overrides
        payload = _deep_merge(payload, payload_overrides)
    
        out = self._post(
            cfg["endpoint"],
            headers,
            payload,
            timeout=request_overrides.get("_timeout", 30),
        )
    
        text = out["choices"][0]["message"]["content"]
        latency = float((time.perf_counter() - start) * 1000.0)
        return {"query": query, "response": text, "latency_ms": latency}

    def _call_grok(
        self, env_key: str, query: str,
        payload_overrides: Dict[str, Any],
        request_overrides: Dict[str, Any],
    ) -> Response:
        """Process requests to Grok language models."""
        start = time.perf_counter()
        cfg = self.env[env_key]
    
        headers = {
            "Content-Type": "application/json",
            "api-key": cfg["key"],
        }
        headers = {**headers, **(request_overrides.get("_headers") or {})}
    
        payload = {
            "messages": [{"role": "user", "content": query}],
            "max_tokens": 500,
            "model": self.model_type,
        }
    
        # Merge dictionary objects applying precedence rules
        payload = _deep_merge(payload, cfg.get("default_params", {}) or {})
        # Apply strict per-call overrides
        payload = _deep_merge(payload, payload_overrides)
    
        out = self._post(
            cfg["endpoint"],
            headers,
            payload,
            timeout=request_overrides.get("_timeout", 30),
        )
    
        text = out["choices"][0]["message"]["content"]
        latency = float((time.perf_counter() - start) * 1000.0)
        return {"query": query, "response": text, "latency_ms": latency}

    def _call_anthropic(
        self, env_key: str, query: str,
        payload_overrides: Dict[str, Any],
        request_overrides: Dict[str, Any],
    ) -> Response:
        """Process requests to Anthropic (Claude) Language Models."""
        start = time.perf_counter()
        cfg = self.env[env_key]
    
        headers = {
            "Content-Type": "application/json",
            "x-api-key": cfg["headers"]["x-api-key"],
            "anthropic-version": cfg["headers"]["anthropic-version"],
        }
        headers = {**headers, **(request_overrides.get("_headers") or {})}
    
        payload = {
            "messages": [{"role": "user", "content": query}],
            "max_tokens": 1000,
            "model": self.model_type,
        }
    
        payload = _deep_merge(payload, cfg.get("default_params", {}) or {})
        payload = _deep_merge(payload, payload_overrides)
    
        out = self._post(
            cfg["endpoint"],
            headers,
            payload,
            timeout=request_overrides.get("_timeout", 30),
        )
    
        text = out["content"][0]["text"]
        latency = float((time.perf_counter() - start) * 1000.0)
        return {"query": query, "response": text, "latency_ms": latency}


    def _call_custom(
        self, env_key: str, query: str,
        payload_overrides: Dict[str, Any],
        request_overrides: Dict[str, Any],
    ) -> Response:
        """Process API requests toward a user-defined custom endpoint implementation with full template variability mapping."""
        start = time.perf_counter()
        cfg = self.env[env_key]
    
        endpoint = cfg["endpoint"]
        method = request_overrides.get("_method", cfg.get("method", "POST")).upper()
    
        headers = cfg.get("headers", {}) or {}
        headers = {**headers, **(request_overrides.get("_headers") or {})}
    
        payload_template = cfg.get("payload", {"query": "${query}"})
        payload = _render_template(payload_template, query=query)
    
        payload = _deep_merge(payload, cfg.get("default_params", {}) or {})
        payload = _deep_merge(payload, payload_overrides)
    
        r = requests.request(
            method=method,
            url=endpoint,
            headers=headers,
            json=payload,
            timeout=request_overrides.get("_timeout", cfg.get("timeout", 30)),
        )
        r.raise_for_status()
        out = r.json()
    
        path = cfg.get("response_path")
        value = _extract_from_path(out, path) if path else out
        text = str(value)
    
        latency = float((time.perf_counter() - start) * 1000.0)
        return {"query": query, "response": text, "latency_ms": latency}


__all__ = ["Response", "ModelEndpoints"]
