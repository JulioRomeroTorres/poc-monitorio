"""
Module for running batch evaluations against multiple models.
"""
from __future__ import annotations

import random
from typing import Any, Callable, Dict, Iterable, List, Optional

from azure.ai.evaluation import evaluate
from azure.ai.evaluation import AzureOpenAIModelConfiguration

from .env import build_model_config_from_env, get_default_credential
from .evaluators import build_evaluators, build_evaluator_config
from .endpoints import ModelEndpoints


def run_batch_evaluation(
    *,
    models: Iterable[str],
    data_path: str,
    env_var: Dict[str, Dict[str, str]],
    azure_ai_project: str,
    evaluators: Optional[Dict[str, Any]] = None,
    evaluator_config: Optional[Dict[str, Any]] = None,
    model_config: Optional[AzureOpenAIModelConfiguration] = None,
    credential: Optional[Any] = None,
    evaluation_name_prefix: str = "Eval-Run",
    id_generator: Optional[Callable[[str], str]] = None,

    enable_custom_judges: bool = False,
    custom_judge_model: Optional[str] = None,
    custom_judge_prompty_dir: Optional[str] = None,
    custom_judge_pattern: str = "*.prompty",
    custom_judge_name_prefix: str = "",
) -> List[Any]:
    """
    Executes a batch evaluation iteratively over a provided list of models, targeting an Azure AI Project workspace.
    
    Args:
        models: An iterable of model names to evaluate.
        data_path: Path to the dataset to evaluate against.
        env_var: Dictionary holding environment configurations for the models.
        azure_ai_project: The Azure AI workspace project identifier.
        evaluators: A custom dictionary of evaluator objects. Defaults to dynamically building them.
        evaluator_config: A custom dictionary mapping evaluators to data. Defaults to dynamically building them.
        model_config: The foundational Azure OpenAI model configuration.
        credential: The Azure identity credential object.
        evaluation_name_prefix: A prefix mapping string for identifying the evaluation runs in the studio.
        id_generator: A callback to generate unique suffixes for each model's run.
        enable_custom_judges: Whether to scan and enable Prompty files as custom LLM-as-a-judge nodes.
        custom_judge_model: Specific deployment name for the custom judge evaluator LLM.
        custom_judge_prompty_dir: Directory containing `.prompty` custom judge templates.
        custom_judge_pattern: The glob pattern to catch custom judges.
        custom_judge_name_prefix: A prefix to append to custom judge keys.
        
    Returns:
        List[Any]: A list containing the evaluation results summary for each model.
    """
    if model_config is None:
        model_config = build_model_config_from_env()

    if credential is None:
        credential = get_default_credential()

    if evaluators is None:
        evaluators = build_evaluators(
            model_config=model_config,
            credential=credential,
            azure_ai_project=azure_ai_project,
            enable_custom_judges=enable_custom_judges,
            custom_judge_model=custom_judge_model,
            custom_judge_prompty_dir=custom_judge_prompty_dir,
            custom_judge_pattern=custom_judge_pattern,
            custom_judge_name_prefix=custom_judge_name_prefix,
        )

    if evaluator_config is None:
        evaluator_config = build_evaluator_config(
            include_custom_judges=enable_custom_judges,
            custom_judge_prompty_dir=custom_judge_prompty_dir,
            custom_judge_pattern=custom_judge_pattern,
            custom_judge_name_prefix=custom_judge_name_prefix,
        )

    results: List[Any] = []

    def _default_id(_: str) -> str:
        """Generates a default random string suffix for the run name."""
        return str(random.randint(1111, 9999))

    id_func = id_generator or _default_id

    # Iterate over the provided models mapping the execution to Azure AI Studio runs
    for model in models:
        run_suffix = id_func(model)
        run_name = f"{evaluation_name_prefix}-{run_suffix}-{model.title()}"
        target = ModelEndpoints(env_var, model)

        res = evaluate(
            evaluation_name=run_name,
            data=data_path,
            target=target,
            evaluators=evaluators,
            azure_ai_project=azure_ai_project,
            evaluator_config=evaluator_config,
        )

        results.append(res)

    return results


__all__ = ["run_batch_evaluation"]
