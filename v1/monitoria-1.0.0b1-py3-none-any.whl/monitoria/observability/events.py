"""
Core module for integrating generative AI telemetry events into OpenTelemetry spans.
Provides the primary `tracking_genai` decorator, establishing operational metrics
such as tokens, latency, model parameters, and semantic context directly into trace histories.
"""
from __future__ import annotations

from opentelemetry.propagate import extract
from opentelemetry import trace as trace_api
from opentelemetry.trace import Status, StatusCode

import asyncio
import json
import logging
import os
import random
import time
from functools import wraps
from typing import Any, Callable, Optional, Literal, Iterable
import inspect


def _hex_span_id(span_id: int) -> str:
    """Format span ID into standard hexadecimal 16-character string."""
    return format(int(span_id), "016x")

def _hex_trace_id(trace_id: int) -> str:
    """Format trace ID into standard hexadecimal 32-character string."""
    return format(int(trace_id), "032x")

__all__ = ["Operation", "set_genai_span_attrs", "tracking_genai"]

log = logging.getLogger(__name__)

Operation = Literal["chat", "embedding", "rag", "e2e", "agent-route-post"]


def set_genai_span_attrs(
    span,
    *,
    session_id: Optional[str] = None,
    service: str = "openai",
    operation: Operation = "chat",
    model: Optional[str] = None,
    server_host: str = "",
    temperature: Optional[float] = None,
    embedding_dimension: Optional[int] = None,
    input_tokens: Optional[float] = None,
    output_tokens: Optional[float] = None,
    total_tokens: Optional[float] = None,
    latency_ms: Optional[int] = None,
    n_chunks: Optional[int] = None,
) -> None:
    """
    Registers a comprehensive set of valid generative AI attributes according to the Semantic Conventions of OpenTelemetry.
    Automatically casts metrics to safe numeric formats avoiding span export errors.
    """
    if session_id:
        span.set_attribute("session.id", session_id)

    span.set_attribute("gen_ai.service", service)
    span.set_attribute("gen_ai.operation.name", operation)
    span.set_attribute("server.address", server_host or "")

    if model is not None:
        try:
            span.set_attribute("gen_ai.operation.model", model)
        except (TypeError, ValueError):
            pass

    if latency_ms is not None:
        try:
            span.set_attribute("gen_ai.response.latency_ms", int(latency_ms))
        except (TypeError, ValueError):
            pass

    if input_tokens is not None:
        try:
            span.set_attribute("gen_ai.usage.input_tokens", int(input_tokens))
        except (TypeError, ValueError):
            pass

    if output_tokens is not None:
        try:
            span.set_attribute("gen_ai.usage.output_tokens", int(output_tokens))
        except (TypeError, ValueError):
            pass

    if total_tokens is not None:
        try:
            span.set_attribute("gen_ai.usage.total_tokens", int(total_tokens))
        except (TypeError, ValueError):
            pass

    op = (operation or "").lower()
    if op == "chat":
        if temperature is not None:
            try:
                span.set_attribute("gen_ai.request.temperature", float(temperature))
            except (TypeError, ValueError):
                pass

    elif op == "embedding":
        if embedding_dimension is not None:
            try:
                span.set_attribute("gen_ai.operation.dimension", int(embedding_dimension))
            except (TypeError, ValueError):
                pass

    elif op == "rag":
        if n_chunks is not None:
            try:
                span.set_attribute("gen_ai.operation.n_chunks", int(n_chunks))
            except (TypeError, ValueError):
                pass


def tracking_genai(
    server_host: str,
    session_id: str,
    tracer: Optional[Any],
    operation_type: str,
    service_type: str,
    sample_rate: float = 1.0,
    rng: Optional[random.Random] = None,
    default_span_name: Optional[str] = None,
    *,
    capture_inputs: bool = False,
    inputs_max_len: int = 1000000,
    inputs_denylist: Optional[Iterable[str]] = None,
    carrier_mode: Literal["off", "fallback",  "force"] = "fallback",
) -> Callable:
    """
    Decorator that instruments a function (sync or async) with a observability span and
    attaches generative AI attributes to the span via `set_genai_span_attrs`.

    If capture_inputs=True, saves input keyword arguments automatically as attributes, 
    truncating at inputs_max_len to prevent export payloads from growing uncontrollably.
    """

    def _extract_parent_context_from_self(args: tuple) -> Any:
        """Resolve and extract internal OTEL contexts from the class instance reference dynamically."""
        if not args:
            return None
        
        self_obj = args[0]
        carrier = getattr(self_obj, "_otel_propagation_carrier", None)
        
        if not isinstance(carrier, dict) or not carrier:
            return None

        try:
            return extract(carrier)
        except Exception as e:
            return None

    def _get_metric(out: Any, name: str) -> Optional[int]:
        """Dynamically extract and type-cast a numeric metric from a given dictionary object output."""
        if out is None:
            return None
        try:
            if isinstance(out, dict):
                val = out.get(name)
            else:
                val = getattr(out, name)
            return int(val) if val is not None else None
        except Exception:
            return None

    def _build_attrs(op: Operation, kwargs: dict, out: Any) -> dict:  
        """Precomputes attribute dictionaries mapping generic outputs into normalized semantic AI conventions."""
        if op == "embedding":  
            return {  
                "model": kwargs.get("model"),  
                "embedding_dimension": _get_metric(out, "embedding_dimension"),  
                "input_tokens": _get_metric(out, "input_tokens"),  
                "total_tokens": _get_metric(out, "total_tokens"),  
            }  
        elif op == "rag":  
            return {  
                "n_chunks": kwargs.get("n_chunks")  
            }  
        elif op == "chat":  
            return {  
                "model": kwargs.get("model"),  
                "temperature": kwargs.get("temperature"),  
                "input_tokens": _get_metric(out, "input_tokens"),  
                "output_tokens": _get_metric(out, "output_tokens"),  
                "total_tokens": _get_metric(out, "total_tokens"),  
            }  
        elif op == "e2e":  
            return {}  
        else:  
            return {} 
        
    def _set_output(span: Any, out: Any, *, output_attr: str = "custom_function.output", max_len: int = 1000000) -> None:
        """Translates final function returns into a stringified JSON schema, dumping inside an OpenTelemetry Span."""
        try:
            cls_name = out.__class__.__name__
            if cls_name in {"ChatCompletion", "CreateEmbeddingResponse"}:
                payload = out.model_dump() if hasattr(out, "model_dump") else {}

            elif hasattr(out, "model_dump"):
                payload = out.model_dump()

            elif isinstance(out, dict):
                payload = out
            
            else:
                payload = getattr(out, "__dict__", None) or str(out)

            s = json.dumps(payload, default = str, ensure_ascii=False) if not isinstance(payload, str) else payload
            span.set_attribute(output_attr, s[:max_len])
        
        except Exception as e:
            pass

    def inside_decorator(func: Callable) -> Callable:
        if tracer is None:
            return func

        is_async = asyncio.iscoroutinefunction(func)
        span_default = default_span_name or f"{service_type}.{operation_type}"
        _rng = rng or random

        # Internal Default Denylist for omitting critically robust or sensitive attributes inside spans
        deny = set(
            k.lower()
            for k in (
                inputs_denylist
                or {
                    "api_key",
                    "apikey",
                    "key",
                    "authorization",
                    "headers",
                    "password",
                    "secret",
                    "client_secret",
                    "messages",
                    "prompt",
                    "history",
                    "rag_context",
                    "tools",
                    "tool_choice",
                }
            )
        )

        capture_msg_content = (
            os.getenv("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", "true")
            .lower()
            in ("1", "true", "yes")
        )

        def _should_trace() -> bool:
            """Evaluates the randomly normalized sampler configuration dictating span emission metrics."""
            try:
                sr = 1.0 if sample_rate is None else max(0.0, min(1.0, float(sample_rate)))
            except Exception:
                sr = 1.0
            return _rng.random() < sr

        def _safe_attr_value(v: Any) -> Optional[Any]:
            """Truncate and parse variables to string avoiding maximum threshold breaks in trace metadata."""
            if v is None:
                return None
            if isinstance(v, (bool, int, float)):
                return v
            if isinstance(v, str):
                return v[:inputs_max_len]
            if isinstance(v, (list, tuple)):
                if all(isinstance(x, (bool, int, float, str)) for x in v):
                    return [x if not isinstance(x, str) else x[:inputs_max_len] for x in v][:100]
                s = json.dumps(v, ensure_ascii=False, default=str)
                return s[:inputs_max_len]
            if isinstance(v, dict):
                s = json.dumps(v, ensure_ascii=False, default=str)
                return s[:inputs_max_len]
            return str(v)[:inputs_max_len]

        def _is_denied_key(key: str) -> bool:
            """Cross references argument names globally blocking secrets from leaking."""
            kl = key.lower()
            if kl in deny:
                # Allow message-ish keys only if explicitly enabled by telemetry setup limits
                if capture_msg_content and kl in {
                    "messages",
                    "prompt",
                    "history",
                    "rag_context",
                    "tools",
                    "tool_choice",
                }:
                    return False
                return True
            return False

        def _flatten_one_level(prefix: str, d: dict) -> list[tuple[str, Any]]:
            """Flatten one dimension within a nested request schema."""
            out = []
            for k, v in d.items():
                key = f"{prefix}.{k}" if prefix else str(k)
                out.append((key, v))
            return out

        def _collect_call_inputs(func: Callable, args: tuple, kwargs: dict) -> dict:
            """Binds physical execution function positional elements into named keyword values universally."""
            collected = {}
            try:
                sig = inspect.signature(func)
                bound = sig.bind(*args, **kwargs)
                bound.apply_defaults()
                collected.update(bound.arguments)
            except Exception:
                for i,a in enumerate(args):
                    collected[f"arg{i}"] = a
                collected.update(kwargs)
            return collected

        def _set_inputs(span: Any, func: Callable, args: tuple, kwargs: dict) -> None:
            """Records bound keyword dictionaries routing exclusively requested variables over into OTEL."""
            try:
                span.set_attribute("custom_function.name", getattr(func, "__name__", str(func)))
            except Exception:
                pass

            if not capture_inputs:
                return

            all_inputs = _collect_call_inputs(func, args, kwargs)
            all_inputs.pop("span_name", None)

            inputs_dict = {}

            if isinstance(all_inputs.get("call_args"), dict):
                call_args = all_inputs.pop("call_args")
                for k, v in _flatten_one_level("", call_args):
                    if not _is_denied_key(k):
                        inputs_dict[k] = v

            for k, v in all_inputs.items():
                if k == "self":
                    continue
                if not _is_denied_key(k):
                    inputs_dict[k] = v

            try:
                s = json.dumps(inputs_dict, ensure_ascii=False, default=str)
                span.set_attribute("custom_function.input", s[:inputs_max_len])
            except Exception:
                pass

        def _common_attrs(span: Any, latency_ms: int) -> dict:
            return {
                "span": span,
                "server_host": server_host,
                "session_id": session_id,
                "latency_ms": latency_ms,
                "operation": operation_type,
                "service": service_type,
            }

        @wraps(func)
        async def awrapper(*args, **kwargs):
            if not _should_trace():
                return await func(*args, **kwargs)

            span_name = kwargs.pop("span_name", span_default)

            current_sc = trace_api.get_current_span().get_span_context()

            parent_otel_ctx = None
            parent_sc = current_sc

            if carrier_mode != "off":
                candidate_ctx = _extract_parent_context_from_self(args)
                if candidate_ctx is not None:
                    if carrier_mode == "force" or (carrier_mode == "fallback" and not current_sc.is_valid):
                        parent_otel_ctx = candidate_ctx
                        parent_sc = trace_api.get_current_span(parent_otel_ctx).get_span_context()

            parent_span_id = _hex_span_id(parent_sc.span_id) if parent_sc.is_valid else None

            t0 = time.perf_counter()

            span_cm = (
                tracer.start_as_current_span(span_name, context=parent_otel_ctx)
                if parent_otel_ctx is not None
                else tracer.start_as_current_span(span_name)
            )   
            
            with span_cm as span:
                ctx = span.get_span_context()
                span.set_attribute("otel.trace_id", _hex_trace_id(ctx.trace_id))
                span.set_attribute("otel.span_id", _hex_span_id(ctx.span_id))

                if parent_span_id is not None:
                    span.set_attribute("otel.parent_span_id", parent_span_id)
                
                try:
                    _set_inputs(span, func, args, kwargs)

                    func_output = await func(*args, **kwargs)
                    latency_ms = int((time.perf_counter() - t0) * 1000)

                    _set_output(span, func_output)
                    payload = _build_attrs(operation_type, kwargs, func_output)
                    set_genai_span_attrs(**_common_attrs(span, latency_ms), **payload)
                    return func_output

                except Exception as e:
                    try:
                        span.set_status(Status(StatusCode.ERROR, str(e)))
                        span.record_exception(e)
                        span.set_attribute("error.type", e.__class__.__name__)
                        span.set_attribute("error.message", str(e))
                    except Exception:
                        pass
                    raise

        @wraps(func)
        def swrapper(*args, **kwargs):
            if not _should_trace():
                return func(*args, **kwargs)

            span_name = kwargs.pop("span_name", span_default)

            current_sc = trace_api.get_current_span().get_span_context()

            parent_otel_ctx = None
            parent_sc = current_sc


            if carrier_mode != "off":
                candidate_ctx = _extract_parent_context_from_self(args)
                if candidate_ctx is not None:
                    if carrier_mode == "force" or (carrier_mode == "fallback" and not current_sc.is_valid):
                        parent_otel_ctx = candidate_ctx
                        parent_sc = trace_api.get_current_span(parent_otel_ctx).get_span_context()

            parent_span_id = _hex_span_id(parent_sc.span_id) if parent_sc.is_valid else None

            t0 = time.perf_counter()

            span_cm = (
                tracer.start_as_current_span(span_name, context=parent_otel_ctx)
                if parent_otel_ctx is not None
                else tracer.start_as_current_span(span_name)
            )

            with span_cm as span:

                ctx = span.get_span_context()
                span.set_attribute("otel.trace_id", _hex_trace_id(ctx.trace_id))
                span.set_attribute("otel.span_id", _hex_span_id(ctx.span_id))
                
                if parent_span_id is not None:
                    span.set_attribute("otel.parent_span_id", parent_span_id)
                
                try:
                    _set_inputs(span, func, args, kwargs)

                    func_output = func(*args, **kwargs)
                    latency_ms = int((time.perf_counter() - t0) * 1000)

                    _set_output(span, func_output)
                    payload = _build_attrs(operation_type, kwargs, func_output)
                    set_genai_span_attrs(**_common_attrs(span, latency_ms), **payload)
                    return func_output

                except Exception as e:
                    try:
                        span.set_status(Status(StatusCode.ERROR, str(e)))
                        span.record_exception(e)
                        span.set_attribute("error.type", e.__class__.__name__)
                        span.set_attribute("error.message", str(e))
                    except Exception:
                        pass
                    raise

        return awrapper if is_async else swrapper

    return inside_decorator
