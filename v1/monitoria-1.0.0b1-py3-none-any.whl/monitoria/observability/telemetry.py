from __future__ import annotations

import logging
import os
import threading
import uuid
from typing import Optional, Mapping, Any, Tuple
from urllib.parse import urlparse

from opentelemetry import trace, metrics
from opentelemetry.trace import Tracer


# OTLP / SDK Imports
from opentelemetry.sdk.resources import Resource, SERVICE_NAME
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor, ConsoleSpanExporter
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter

from opentelemetry._logs import set_logger_provider
from opentelemetry.sdk._logs import LoggerProvider
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter

try:
    from azure.monitor.opentelemetry import configure_azure_monitor
except ImportError:
    configure_azure_monitor = None

__all__ = [
    "init_telemetry",
]

log = logging.getLogger(__name__)

_TELEMETRY_READY = False
_INIT_LOCK = threading.Lock()
_TRACER: Optional[Tracer] = None
_SESSION_ID: Optional[str] = None
_SERVER_HOST: str = ""

DEFAULT_API_VERSION = "2024-10-21"


def init_telemetry(
    *,
    appinsights_connection_string: Optional[str] = None,
    otlp_endpoint: Optional[str] = None,
    service_name: Optional[str] = None,
    capture_message_content: Optional[bool] = None,
    trace_to_console: Optional[bool] = None,
    mutate_env: bool = True,
) -> Tuple[Tracer, str, str]:
    """
    One-time, idempotent OpenTelemetry + Azure Monitor setup for the process.
    Supports exporting to either Azure Monitor (Application Insights) or an OTLP endpoint.

    Returns:
        (tracer, session_id, server_host)

    Safe to call multiple times; subsequent calls return cached values.
    """
    global _TELEMETRY_READY, _TRACER, _SESSION_ID, _SERVER_HOST

    # Fast path if already initialized
    if _TELEMETRY_READY and _TRACER and _SESSION_ID is not None:
        return _TRACER, _SESSION_ID, _SERVER_HOST

    with _INIT_LOCK:
        if _TELEMETRY_READY and _TRACER and _SESSION_ID is not None:
            return _TRACER, _SESSION_ID, _SERVER_HOST

        # Resolve configuration
        resolved_service_name = service_name or os.getenv("OTEL_SERVICE_NAME") or "program-ai-app"
        resolved_capture = (
            capture_message_content
            if capture_message_content is not None
            else os.getenv("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", "true").lower()
            in ("1", "true", "yes")
        )
        resolved_trace_to_console = (
            trace_to_console
            if trace_to_console is not None
            else os.getenv("OTEL_TRACE_TO_CONSOLE", "false").lower() in ("1", "true", "yes")
        )
        resolved_otlp_endpoint = otlp_endpoint or os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")

        # Mutate environment only if requested
        if mutate_env:
            os.environ.setdefault("OTEL_SERVICE_NAME", resolved_service_name)
            os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] = (
                "true" if resolved_capture else "false"
            )

        conn_str = appinsights_connection_string or os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")

        # Determine which path to take: OTLP or Azure Monitor
        if resolved_otlp_endpoint:
            # OTLP Gateway Configuration Path
            log.info(f"Configuring OpenTelemetry to export to OTLP Gateway: {resolved_otlp_endpoint}")
            
            resource = Resource.create({SERVICE_NAME: resolved_service_name})

            # 1. Traces Configuration
            trace_provider = TracerProvider(resource=resource)
            otlp_trace_exporter = OTLPSpanExporter(endpoint=f"{resolved_otlp_endpoint.rstrip('/')}/v1/traces")
            trace_provider.add_span_processor(BatchSpanProcessor(otlp_trace_exporter))
            trace.set_tracer_provider(trace_provider)

            # 2. Metrics Configuration
            otlp_metric_exporter = OTLPMetricExporter(endpoint=f"{resolved_otlp_endpoint.rstrip('/')}/v1/metrics")
            metric_reader = PeriodicExportingMetricReader(otlp_metric_exporter)
            meter_provider = MeterProvider(resource=resource, metric_readers=[metric_reader])
            metrics.set_meter_provider(meter_provider)

            # 3. Logs Configuration
            logger_provider = LoggerProvider(resource=resource)
            otlp_log_exporter = OTLPLogExporter(endpoint=f"{resolved_otlp_endpoint.rstrip('/')}/v1/logs")
            logger_provider.add_log_record_processor(BatchLogRecordProcessor(otlp_log_exporter))
            set_logger_provider(logger_provider)
            
            # Use OTLP endpoint as server_host
            resolved_endpoint_for_host = resolved_otlp_endpoint

        else:
            # Azure Monitor Configuration Path
            if not conn_str:
                raise RuntimeError(
                    "No telemetry destination configured. Provide `otlp_endpoint` / OTEL_EXPORTER_OTLP_ENDPOINT, "
                    "or `appinsights_connection_string` / APPLICATIONINSIGHTS_CONNECTION_STRING."
                )

            if configure_azure_monitor is None:
                log.warning("azure-monitor-opentelemetry is not installed. Tracing to Azure Monitor won't work.")
            else:
                log.info("Configuring OpenTelemetry to export to Azure Monitor")
                # Configure Azure Monitor OpenTelemetry exporter
                configure_azure_monitor(connection_string=conn_str,
                                        sampling_ratio=1.0,
                                        instrumentation_options={
                                            "fastapi": {"enabled": False},
                                            "requests": {"enabled": False},
                                            "urllib3": {"enabled": False},
                                            "azure_sdk": {"enabled": False},
                                        })
            
            resolved_endpoint_for_host = ""
            for part in conn_str.split(";"):
                if part.lower().startswith("ingestionendpoint="):
                    resolved_endpoint_for_host = part.split("=", 1)[1]
                    break

        # Instrument OpenAI SDK if present (non-fatal if unavailable)
        try:
            from opentelemetry.instrumentation.openai import OpenAIInstrumentor
            OpenAIInstrumentor().instrument()
        except Exception as e:
            log.debug("OpenAIInstrumentor instrumentation skipped: %s", e)

        # Optional console exporter for local debugging
        if resolved_trace_to_console:
            try:
                from opentelemetry import trace as trace_api
                from opentelemetry.sdk.trace.export import SimpleSpanProcessor, ConsoleSpanExporter

                provider = trace_api.get_tracer_provider()
                if hasattr(provider, "add_span_processor"):
                    provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
                    log.info("Console span exporter enabled; intended for local debugging.")
            except Exception as e:
                log.debug("Failed to enable console span exporter: %s", e)

        # Finalize tracer and metadata
        _TRACER = trace.get_tracer(__name__)
        _SESSION_ID = _SESSION_ID or str(uuid.uuid4())
        _SERVER_HOST = urlparse(resolved_endpoint_for_host).hostname or ""

        _TELEMETRY_READY = True
        return _TRACER, _SESSION_ID, _SERVER_HOST

def enable_auto_instrumentation(enable_sensitive_data: Optional[bool] = None) -> None:
    """
    Enable automatic spans for common core frameworks (e.g., Azure AI and Microsoft Agent Framework).
    Call this alongside or after init_telemetry() inside your bootstrapper.
    """
    try:
        from azure.core.settings import settings
        settings.tracing_implementation = "opentelemetry"
        log.debug("Azure Core observability implementation forced to OpenTelemetry.")
    except ImportError:
        pass

    try:
        from agent_framework.observability import enable_instrumentation
        
        if enable_sensitive_data is None:
            enable_sensitive_data = os.getenv("ENABLE_SENSITIVE_DATA", "false").lower() in ("1", "true", "yes")

        enable_instrumentation(enable_sensitive_data=enable_sensitive_data)
        log.info(f"Agent Framework auto-instrumentation enabled. Sensitive Data: {enable_sensitive_data}")
        
    except ImportError:
        log.debug("agent_framework is not installed; skipping Agent Framework auto spans.")
    except Exception as e:
        log.warning("Failed to enable Agent Framework auto spans: %s", e)