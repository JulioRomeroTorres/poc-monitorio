import json
from typing import Callable, Dict, Optional, Any

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import StreamingResponse, Response

from opentelemetry.context import attach, detach
from opentelemetry.trace import Status, StatusCode
from opentelemetry.trace import set_span_in_context

class GenAITrackingSSEMiddleware(BaseHTTPMiddleware):
    """
    OpenTelemetry Middleware integrated into the monitoria library that:
    - Creates a span per request for selected REST routes.
    - Captures the request input parameters formatted to "custom_endpoint.*".
    - Wraps async StreamingResponse flows properly holding spans active in context.
    """

    def __init__(
        self,
        app,
        tracer,
        service_name: str,
        operation_map: Optional[Dict[str, str]] = None,
        capture_inputs: bool = True,
        capture_input_max_len: int = 2000,
        enabled_paths: Optional[set[str]] = None,
        carrier_mode: str = "fallback",
    ):
        super().__init__(app)
        self.tracer = tracer
        self.service_name = service_name
        self.operation_map = operation_map or {}
        self.capture_inputs = capture_inputs
        self.capture_input_max_len = capture_input_max_len
        self.enabled_paths = enabled_paths
        self.carrier_mode = carrier_mode

    def _operation_name(self, request: Request) -> str:
        key = f"{request.method.upper()}:{request.url.path}"
        return self.operation_map.get(key, f"{request.method.lower()}:{request.url.path}")

    async def _try_get_json_body(self, request: Request) -> Optional[Dict[str, Any]]:
        try:
            raw = await request.body()
            if not raw:
                return None
            return json.loads(raw.decode("utf-8", errors="ignore"))
        except Exception:
            return None

    async def dispatch(self, request: Request, call_next: Callable):
        if self.enabled_paths and request.url.path not in self.enabled_paths:
            return await call_next(request)

        operation_name = self._operation_name(request)

        body_json = None
        if self.capture_inputs:
            body_json = await self._try_get_json_body(request)

        span_name = f"genai.http {request.method.upper()} {request.url.path}"

        span = self.tracer.start_span(span_name)
        span_context = set_span_in_context(span)
        token = attach(span_context)

        try:
            # Custom Endpoint core tags
            span.set_attribute("custom_endpoint.name", request.url.path)
            
            # Additional Standard Metadata
            span.set_attribute("custom_attrs.service_name", self.service_name)
            span.set_attribute("custom_attrs.operation_name", operation_name)

            span.set_attribute("http.method", request.method)
            span.set_attribute("http.route", request.url.path)

            if self.capture_inputs:
                inputs_dict = {}
                if body_json:
                    inputs_dict["body"] = body_json
                if request.query_params:
                    inputs_dict["query_params"] = dict(request.query_params)
                if dict(request.headers):
                    inputs_dict["headers"] = {k: v for k, v in request.headers.items() if k.lower() not in {"authorization", "cookie"}}
                
                try:
                    s = json.dumps(inputs_dict, ensure_ascii=False, default=str)
                    span.set_attribute("custom_endpoint.input", s[:self.capture_input_max_len])
                except Exception:
                    pass

            response: Response = await call_next(request)

            # In Starlette's BaseHTTPMiddleware, call_next ALWAYS returns a _StreamingResponse
            # which does not have a .body attribute, but instead streams chunks via body_iterator.
            # We unconditionally wrap the iterator to intercept the payload for ALL responses.
            original_iter = response.body_iterator

            async def wrapped_iter():
                inner_token = attach(span_context)
                captured_chunks = []
                try:
                    async for chunk in original_iter:
                        # Silently capture chunks for observability
                        if self.capture_inputs:
                            if isinstance(chunk, bytes):
                                captured_chunks.append(chunk.decode("utf-8", errors="ignore"))
                            elif isinstance(chunk, str):
                                captured_chunks.append(chunk)

                        yield chunk

                    status_code = getattr(response, "status_code", 200)
                    span.set_attribute("http.status_code", status_code)
                    
                    output_dict = {"status_code": status_code, "streaming": True}
                    
                    if captured_chunks:
                        assembled_body = "".join(captured_chunks)
                        # Try to parse single JSON stream output if possible
                        try:
                            output_dict["body"] = json.loads(assembled_body)
                        except Exception:
                            output_dict["body"] = assembled_body

                    try:
                        out_str = json.dumps(output_dict, ensure_ascii=False, default=str)
                        span.set_attribute("custom_endpoint.output", out_str[:self.capture_input_max_len])
                    except Exception:
                        pass

                    span.set_status(Status(StatusCode.OK))

                except Exception as e:
                    span.record_exception(e)
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    raise

                finally:
                    detach(inner_token)
                    span.end()

            response.body_iterator = wrapped_iter()
            return response

        except Exception as e:
            span.record_exception(e)
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.end()
            raise

        finally:
            detach(token)